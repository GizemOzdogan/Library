package Helpers;

import Interfaces.ConnectionManager;
import Interfaces.GenericRepository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public abstract class AbstractRepository<T> implements GenericRepository<T> {

    private final ConnectionManager connectionManager;

    public AbstractRepository(ConnectionManager connectionManager) {
        this.connectionManager = connectionManager;
    }

    protected abstract String getTableName();

    protected abstract T extractEntityFromResultSet(ResultSet resultSet) throws SQLException;

    protected abstract String generateInsertQuery();

    protected abstract void setInsertValues(PreparedStatement statement, T entity) throws SQLException;

    protected abstract String generateUpdateQuery();

    protected abstract void setUpdateValues(PreparedStatement statement, T entity) throws SQLException;

    protected Connection connect() throws SQLException {
        return connectionManager.connect();
    }

    protected void closeConnection(Connection connection) {
        connectionManager.close(connection);
    }

    @Override
    public void add(T entity) {
        String sql = generateInsertQuery();
        try (Connection connection = connect();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            setInsertValues(statement, entity);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace(); // Handle or log the exception as needed
        }
    }

    @Override
    public T getById(int id) {
        String sql = "SELECT * FROM " + getTableName() + " WHERE Id = ?";
        try (Connection connection = connect();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return extractEntityFromResultSet(resultSet);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Handle or log the exception as needed
        }
        return null;
    }

    @Override
    public List<T> getAll() {
        List<T> entities = new ArrayList<>();
        String sql = "SELECT * FROM " + getTableName();
        try (Connection connection = connect();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                entities.add(extractEntityFromResultSet(resultSet));
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Handle or log the exception as needed
        }
        return entities;
    }

    @Override
    public void update(T entity) {
        String sql = generateUpdateQuery();
        try (Connection connection = connect();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            setUpdateValues(statement, entity);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace(); // Handle or log the exception as needed
        }
    }

    @Override
    public void delete(int id) {
        String sql = "DELETE FROM " + getTableName() + " WHERE Id = ?";
        try (Connection connection = connect();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace(); // Handle or log the exception as needed
        }
    }

    @Override
    public List<T> query(String sql) {
        List<T> entities = new ArrayList<>();
        try (Connection connection = connect();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                entities.add(extractEntityFromResultSet(resultSet));
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Handle or log the exception as needed
        }
        return entities;
    }

    @Override
    public boolean exists(int id) {
        String sql = "SELECT COUNT(*) FROM " + getTableName() + " WHERE Id = ?";
        try (Connection connection = connect();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return resultSet.getInt(1) > 0;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Handle or log the exception as needed
        }
        return false;
    }

    @Override
    public int count() {
        String sql = "SELECT COUNT(*) FROM " + getTableName();
        try (Connection connection = connect();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {
            if (resultSet.next()) {
                return resultSet.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Handle or log the exception as needed
        }
        return 0;
    }

    @Override
    public int count(String sql) {
        try (Connection connection = connect();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {
            if (resultSet.next()) {
                return resultSet.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Handle or log the exception as needed
        }
        return 0;
    }
}
