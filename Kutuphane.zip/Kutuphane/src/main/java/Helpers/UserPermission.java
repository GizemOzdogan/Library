package Helpers;

import Models.CurrentUser;
import Repositories.RoleRepository;
import Repositories.UserRepository;

import java.util.Objects;

public class UserPermission {

    protected CurrentUser _currentUser;
    protected UserRepository _userRepository;
    protected RoleRepository _roleRepository;

    public UserPermission(CurrentUser user) {
        var db = SQLiteConnectionManager.getInstance();
        _userRepository = new UserRepository(db);
        _roleRepository = new RoleRepository(db);
        _currentUser = user;
    }

    public static UserPermission getInstance(CurrentUser user) {
        return new UserPermission(user);
    }

    public Boolean CanModifyBook() throws Exception {

        var userFromDb = _userRepository.getById(_currentUser.getId());
        if (userFromDb == null) {
            throw new Exception("User Not Found :" + _currentUser.getUserName());
        }

        var role = _roleRepository.getById(userFromDb.getRoleId());
        if (role == null) {
            throw new Exception("Role Not Found");
        }

        if (Objects.equals(role.getName(), "Personel")) {
            return true;
        }

        return false;
    }

    public Boolean CanModifyCategory() throws Exception {

        var userFromDb = _userRepository.getById(_currentUser.getId());
        if (userFromDb == null) {
            throw new Exception("User Not Found :" + _currentUser.getUserName());
        }

        var role = _roleRepository.getById(userFromDb.getRoleId());
        if (role == null) {
            throw new Exception("Role Not Found");
        }

        if (Objects.equals(role.getName(), "Personel") || Objects.equals(role.getName(), "Öğretim Görevlisi")) {
            return true;
        }

        return false;
    }

    public Boolean CanModifyUser() throws Exception {

        var userFromDb = _userRepository.getById(_currentUser.getId());
        if (userFromDb == null) {
            throw new Exception("User Not Found :" + _currentUser.getUserName());
        }

        var role = _roleRepository.getById(userFromDb.getRoleId());
        if (role == null) {
            throw new Exception("Role Not Found");
        }

        if (Objects.equals(role.getName(), "Personel")) {
            return true;
        }

        return false;
    }

    public Boolean CanCreateBookTransaction() throws Exception {

        var userFromDb = _userRepository.getById(_currentUser.getId());
        if (userFromDb == null) {
            throw new Exception("User Not Found :" + _currentUser.getUserName());
        }

        var role = _roleRepository.getById(userFromDb.getRoleId());
        if (role == null) {
            throw new Exception("Role Not Found");
        }

        if (Objects.equals(role.getName(), "Öğretim Görevlisi") || Objects.equals(role.getName(), "Personel")) {
            return true;
        }

        return false;
    }

    public Boolean CanNotifyAllTransaction() throws Exception {

        var userFromDb = _userRepository.getById(_currentUser.getId());
        if (userFromDb == null) {
            throw new Exception("User Not Found :" + _currentUser.getUserName());
        }

        var role = _roleRepository.getById(userFromDb.getRoleId());
        if (role == null) {
            throw new Exception("Role Not Found");
        }

        if (Objects.equals(role.getName(), "Personel")) {
            return true;
        }

        return false;
    }

    public Boolean IsStudent() throws Exception {

        var userFromDb = _userRepository.getById(_currentUser.getId());
        if (userFromDb == null) {
            throw new Exception("User Not Found :" + _currentUser.getUserName());
        }

        var role = _roleRepository.getById(userFromDb.getRoleId());
        if (role == null) {
            throw new Exception("Role Not Found");
        }

        if (Objects.equals(role.getName(), "Öğrenci")) {
            return true;
        }

        return false;
    }

    public Boolean IsTeacher() throws Exception {

        var userFromDb = _userRepository.getById(_currentUser.getId());
        if (userFromDb == null) {
            throw new Exception("User Not Found :" + _currentUser.getUserName());
        }

        var role = _roleRepository.getById(userFromDb.getRoleId());
        if (role == null) {
            throw new Exception("Role Not Found");
        }

        if (Objects.equals(role.getName(), "Öğretim Görevlisi")) {
            return true;
        }

        return false;
    }


    public Boolean IsPersonnel() throws Exception {

        var userFromDb = _userRepository.getById(_currentUser.getId());
        if (userFromDb == null) {
            throw new Exception("User Not Found :" + _currentUser.getUserName());
        }

        var role = _roleRepository.getById(userFromDb.getRoleId());
        if (role == null) {
            throw new Exception("Role Not Found");
        }

        if (Objects.equals(role.getName(), "Personel")) {
            return true;
        }

        return false;
    }

    public Boolean CanBookNotifierTransaction() throws Exception {

        var userFromDb = _userRepository.getById(_currentUser.getId());
        if (userFromDb == null) {
            throw new Exception("User Not Found :" + _currentUser.getUserName());
        }

        var role = _roleRepository.getById(userFromDb.getRoleId());
        if (role == null) {
            throw new Exception("Role Not Found");
        }

        if (Objects.equals(role.getName(), "Öğrenci")) {
            return true;
        }

        return false;
    }

}
