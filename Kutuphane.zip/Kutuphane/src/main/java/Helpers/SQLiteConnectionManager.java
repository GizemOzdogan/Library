package Helpers;

import Constants.DatabaseConstants;
import Interfaces.ConnectionManager;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class SQLiteConnectionManager implements ConnectionManager {
    private static final String DATABASE_URL = DatabaseConstants.DB_URL;

    private static SQLiteConnectionManager instance;

    private SQLiteConnectionManager() {}

    public static synchronized SQLiteConnectionManager getInstance() {
        if (instance == null) {
            instance = new SQLiteConnectionManager();
        }
        return instance;
    }

    @Override
    public Connection connect() throws SQLException {
        return DriverManager.getConnection(DATABASE_URL);
    }

    @Override
    public void close(Connection connection) {
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException e) {
                e.printStackTrace(); // Handle or log the exception as needed
            }
        }
    }

    private boolean isDatabaseExists() throws SQLException {
        try (Connection connection = connect()) {
            return connection != null;
        }
    }

    @Override
    public void createDatabaseIfNotExists() throws SQLException {
        if (isDatabaseExists()) {
            executeMigration();
        }
    }

    private void executeMigration() throws SQLException {
        try (Connection connection = connect();
             Statement statement = connection.createStatement()) {

            var isBookTableExists = statement.executeQuery("SELECT name FROM sqlite_master WHERE type='table' AND name='Book';").next();
            if (isBookTableExists) {
                return;
            }

            try (BufferedReader reader = new BufferedReader(new FileReader(DatabaseConstants.DB_INIT_SCRIPT_PATH))) {
                StringBuilder scriptContent = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    scriptContent.append(line);
                }
                var str = scriptContent.toString();
                for (String s : str.split(";")) {
                    statement.execute(s);
                }
            } catch (IOException e) {
                e.printStackTrace();
                throw new SQLException("Database init script could not be read.");
            }
            catch (SQLException e) {
                e.printStackTrace();
                throw new SQLException("Database init script could not be executed.");
            }
            finally {
                statement.close();
                connection.close();
            }
        }
    }
}
