package Repositories;

import Helpers.AbstractRepository;
import Interfaces.ConnectionManager;
import Models.BookStateTransaction;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class BookStateTransactionRepository extends AbstractRepository<BookStateTransaction> {

    public BookStateTransactionRepository(ConnectionManager connectionManager) {
        super(connectionManager);
    }

    @Override
    protected String getTableName() {
        return "BookStateTransaction";
    }

    @Override
    protected BookStateTransaction extractEntityFromResultSet(ResultSet resultSet) throws SQLException {
        return new BookStateTransaction(
                resultSet.getInt("Id"),
                resultSet.getString("PreviousStateName"),
                resultSet.getString("StateName"),
                resultSet.getInt("UserId"),
                resultSet.getInt("BookId"),
                resultSet.getDate("TransactionDate"),
                resultSet.getBoolean("IsRead"),
                resultSet.getBoolean("IsPublic")
        );
    }

    @Override
    protected String generateInsertQuery() {
        return "INSERT INTO " + getTableName() + " (PreviousStateName, StateName, UserId, BookId, TransactionDate,IsRead,IsPublic) VALUES (?, ?, ?, ?, ?,?,?)";
    }

    @Override
    protected void setInsertValues(PreparedStatement statement, BookStateTransaction entity) throws SQLException {
        statement.setString(1, entity.getPreviousStateName());
        statement.setString(2, entity.getStateName());
        statement.setInt(3, entity.getUserId());
        statement.setInt(4, entity.getBookId());
        statement.setDate(5, (Date) entity.getTransactionDate());
        statement.setBoolean(6,entity.getIsRead());
        statement.setBoolean(7,entity.getIsPublic());
    }

    @Override
    protected String generateUpdateQuery() {
        return "UPDATE " + getTableName() + " SET PreviousStateName=?, StateName=?, UserId=?, BookId=?, TransactionDate=?, IsRead=?, IsPublic=? WHERE Id=?";
    }

    @Override
    protected void setUpdateValues(PreparedStatement statement, BookStateTransaction entity) throws SQLException {
        statement.setString(1, entity.getPreviousStateName());
        statement.setString(2, entity.getStateName());
        statement.setInt(3, entity.getUserId());
        statement.setInt(4, entity.getBookId());
        statement.setDate(5, (Date) entity.getTransactionDate());
        statement.setInt(6, entity.getId());
        statement.setBoolean(7,entity.getIsRead());
        statement.setBoolean(8,entity.getIsPublic());
    }
}
