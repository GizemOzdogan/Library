package Repositories;

import Helpers.AbstractRepository;
import Interfaces.ConnectionManager;
import Models.Book;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;




public class BookRepository extends AbstractRepository<Book> {

    public BookRepository(ConnectionManager connectionManager) {
        super(connectionManager);
    }

    @Override
    protected String getTableName() {
        return "Book";
    }

    @Override
    protected Book extractEntityFromResultSet(ResultSet resultSet) throws SQLException {
        return new Book(
                resultSet.getInt("Id"),
                resultSet.getString("Name"),
                resultSet.getString("ISBN"),
                resultSet.getString("Author"),
                resultSet.getInt("CategoryId"),
                resultSet.getInt("BookState")
        );
    }

    @Override
    protected String generateInsertQuery() {
        return "INSERT INTO " + getTableName() + " (Name, ISBN, Author, CategoryId, BookState) VALUES (?, ?, ?, ?, ?)";
    }

    @Override
    protected void setInsertValues(PreparedStatement statement, Book entity) throws SQLException {
        statement.setString(1, entity.getName());
        statement.setString(2, entity.getISBN());
        statement.setString(3, entity.getAuthor());
        statement.setInt(4, entity.getCategoryId());
        statement.setInt(5, entity.getBookState());
    }

    @Override
    protected String generateUpdateQuery() {
        return "UPDATE " + getTableName() + " SET Name=?, ISBN=?, Author=?, CategoryId=?, BookState=? WHERE Id=?";
    }

    @Override
    protected void setUpdateValues(PreparedStatement statement, Book entity) throws SQLException {
        statement.setString(1, entity.getName());
        statement.setString(2, entity.getISBN());
        statement.setString(3, entity.getAuthor());
        statement.setInt(4, entity.getCategoryId());
        statement.setInt(5, entity.getBookState());
        statement.setInt(6, entity.getId());
    }
}
