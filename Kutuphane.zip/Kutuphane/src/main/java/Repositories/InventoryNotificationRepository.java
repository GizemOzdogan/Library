package Repositories;

import Helpers.AbstractRepository;
import Interfaces.ConnectionManager;
import Models.InventoryNotification;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class InventoryNotificationRepository extends AbstractRepository<InventoryNotification> {

    public InventoryNotificationRepository(ConnectionManager connectionManager) {
        super(connectionManager);
    }

    @Override
    protected String getTableName() {
        return "InventoryNotification";
    }

    @Override
    protected InventoryNotification extractEntityFromResultSet(ResultSet resultSet) throws SQLException {
        return new InventoryNotification(
                resultSet.getInt("Id"),
                resultSet.getString("BookName"),
                resultSet.getInt("UserId"),
                resultSet.getDate("NotificationDate"),
                resultSet.getInt("IsRead"),
                resultSet.getDate("ReadDate")
        );
    }

    @Override
    protected String generateInsertQuery() {
        return "INSERT INTO " + getTableName() + " (BookName, UserId, NotificationDate, IsRead, ReadDate) VALUES (?, ?, ?, ?, ?)";
    }

    @Override
    protected void setInsertValues(PreparedStatement statement, InventoryNotification entity) throws SQLException {
        statement.setString(1, entity.getBookName());
        statement.setInt(2, entity.getUserId());
        statement.setDate(3, (Date) entity.getNotificationDate());
        statement.setInt(4, entity.getIsRead());
        statement.setDate(5, (Date) entity.getReadDate());
    }

    @Override
    protected String generateUpdateQuery() {
        return "UPDATE " + getTableName() + " SET BookName=?, UserId=?, NotificationDate=?, IsRead=?, ReadDate=? WHERE Id=?";
    }

    @Override
    protected void setUpdateValues(PreparedStatement statement, InventoryNotification entity) throws SQLException {
        statement.setString(1, entity.getBookName());
        statement.setInt(2, entity.getUserId());
        statement.setDate(3, (Date) entity.getNotificationDate());
        statement.setInt(4, entity.getIsRead());
        statement.setDate(5, (Date) entity.getReadDate());
        statement.setInt(6, entity.getId());
    }
}
