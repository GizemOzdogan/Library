package Repositories;

import Helpers.AbstractRepository;
import Interfaces.ConnectionManager;
import Models.Category;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
public class CategoryRepository extends AbstractRepository<Category> {

    public CategoryRepository(ConnectionManager connectionManager) {
        super(connectionManager);
    }

    @Override
    protected String getTableName() {
        return "Category";
    }

    @Override
    protected Category extractEntityFromResultSet(ResultSet resultSet) throws SQLException {
        return new Category(
                resultSet.getInt("Id"),
                resultSet.getString("Name")
        );
    }

    @Override
    protected String generateInsertQuery() {
        return "INSERT INTO " + getTableName() + " (Name) VALUES (?)";
    }

    @Override
    protected void setInsertValues(PreparedStatement statement, Category entity) throws SQLException {
        statement.setString(1, entity.getName());
    }

    @Override
    protected String generateUpdateQuery() {
        return "UPDATE " + getTableName() + " SET Name=? WHERE Id=?";
    }

    @Override
    protected void setUpdateValues(PreparedStatement statement, Category entity) throws SQLException {
        statement.setString(1, entity.getName());
        statement.setInt(2, entity.getId());
    }
}
