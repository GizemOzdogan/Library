package Repositories;

import Helpers.AbstractRepository;
import Interfaces.ConnectionManager;
import Models.User;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UserRepository extends AbstractRepository<User> {

    public UserRepository(ConnectionManager connectionManager) {
        super(connectionManager);
    }

    @Override
    protected String getTableName() {
        return "User";
    }

    @Override
    protected User extractEntityFromResultSet(ResultSet resultSet) throws SQLException {
        return new User(
                resultSet.getInt("Id"),
                resultSet.getString("Name"),
                resultSet.getString("Username"),
                resultSet.getString("Password"),
                resultSet.getInt("RoleId")
        );
    }

    @Override
    protected String generateInsertQuery() {
        return "INSERT INTO " + getTableName() + " (Name, Username, Password, RoleId) VALUES (?, ?, ?, ?)";
    }

    @Override
    protected void setInsertValues(PreparedStatement statement, User entity) throws SQLException {
        statement.setString(1, entity.getName());
        statement.setString(2, entity.getUsername());
        statement.setString(3, entity.getPassword());
        statement.setInt(4, entity.getRoleId());
    }

    @Override
    protected String generateUpdateQuery() {
        return "UPDATE " + getTableName() + " SET Name=?, Username=?, Password=?, RoleId=? WHERE Id=?";
    }

    @Override
    protected void setUpdateValues(PreparedStatement statement, User entity) throws SQLException {
        statement.setString(1, entity.getName());
        statement.setString(2, entity.getUsername());
        statement.setString(3, entity.getPassword());
        statement.setInt(4, entity.getRoleId());
        statement.setInt(5, entity.getId());
    }
}
