package Repositories;

import Helpers.AbstractRepository;
import Interfaces.ConnectionManager;
import Models.Role;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class RoleRepository extends AbstractRepository<Role> {

    public RoleRepository(ConnectionManager connectionManager) {
        super(connectionManager);
    }

    @Override
    protected String getTableName() {
        return "Role";
    }

    @Override
    protected Role extractEntityFromResultSet(ResultSet resultSet) throws SQLException {
        return new Role(
                resultSet.getInt("Id"),
                resultSet.getString("Name")
        );
    }

    @Override
    protected String generateInsertQuery() {
        return "INSERT INTO " + getTableName() + " (Name) VALUES (?)";
    }

    @Override
    protected void setInsertValues(PreparedStatement statement, Role entity) throws SQLException {
        statement.setString(1, entity.getName());
    }

    @Override
    protected String generateUpdateQuery() {
        return "UPDATE " + getTableName() + " SET Name=? WHERE Id=?";
    }

    @Override
    protected void setUpdateValues(PreparedStatement statement, Role entity) throws SQLException {
        statement.setString(1, entity.getName());
        statement.setInt(2, entity.getId());
    }
}
