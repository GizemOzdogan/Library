module com.kutuphane.kutuphane {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires javafx.graphics;
    requires org.controlsfx.controls;
    requires org.kordamp.bootstrapfx.core;

    opens Interfaces;
    opens Kutuphane;
}