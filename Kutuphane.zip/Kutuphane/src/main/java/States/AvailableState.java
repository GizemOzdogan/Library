package States;

import Models.Book;

public class AvailableState extends BookState {
    public AvailableState(Book book) {
        super(book);
    }

    @Override
    public void borrow() {
        book.setBookState(1);
    }

    @Override
    public void returnBook() {
        throw new RuntimeException("Kitap zaten kütüphanede");
    }

    @Override
    public void lose() {
        book.setBookState(2);
    }

    @Override
    public void found() {
        throw new RuntimeException("Kitap zaten kütüphanede");
    }
}
