package States;

import Models.Book;

//0 - Available
//1 - Borrowed
//2 - Lost

public abstract class BookState {
    Book book;

    public BookState(Book book) {
        this.book = book;
    }

    public abstract void borrow();
    public abstract void returnBook();
    public abstract void lose();
    public abstract void found();

    public static BookState createBookState(Book book) {
        return switch (book.getBookState()) {
            case 0 -> new AvailableState(book);
            case 1 -> new BorrowState(book);
            case 2 -> new LoseState(book);
            default -> throw new RuntimeException("Tanımsız kitap durumu");
        };
    }

    public static String getBookStateName(int bookState) {
        return switch (bookState) {
            case 0 -> "Mevcut";
            case 1 -> "Ödünç Alınmış";
            case 2 -> "Kayıp";
            default -> "Tanımsız";
        };
    }

    // override toString method
    @Override
    public String toString() {
        return getBookStateName(book.getBookState());
    }
}
