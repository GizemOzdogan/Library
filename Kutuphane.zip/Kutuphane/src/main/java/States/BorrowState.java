package States;

import Models.Book;

public class BorrowState extends BookState {
    public BorrowState(Book book) {
        super(book);
    }

    @Override
    public void borrow() {
        throw new RuntimeException("Kitap zaten ödünç alınmış");
    }

    @Override
    public void returnBook() {
        book.setBookState(0);
    }

    @Override
    public void lose() {
        book.setBookState(2);
    }

    @Override
    public void found() {
        throw new RuntimeException("Kitap zaten ödünç alınmış");
    }
}
