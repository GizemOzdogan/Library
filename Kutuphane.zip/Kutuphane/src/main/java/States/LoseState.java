package States;

public class LoseState extends  BookState {
    public LoseState(Models.Book book) {
        super(book);
    }

    @Override
    public void borrow() {
        throw new RuntimeException("Kitap kayıp olduğu için ödünç verilemez");
    }

    @Override
    public void returnBook() {
        throw new RuntimeException("Kitap kayıp olduğu için iade edilemez");
    }

    @Override
    public void lose() {
        throw new RuntimeException("Kitap zaten kayıp");
    }

    @Override
    public void found() {
        book.setBookState(0);
    }
}
