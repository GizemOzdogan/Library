package Kutuphane;

import Application.KategoriDialog;
import Helpers.FXRouter;
import Helpers.SQLiteConnectionManager;
import Helpers.UserPermission;
import Models.Book;
import Models.Category;
import Models.CurrentUser;
import Models.User;
import Repositories.CategoryRepository;
import javafx.application.Platform;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;
import javafx.util.Callback;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

public class KategoriController extends BaseController {

    private CategoryRepository _categoryRepository;
    private UserPermission _userPermission;
    private ObservableList<Category> _kategoriData;

    public KategoriController() {
        _categoryRepository = new CategoryRepository(SQLiteConnectionManager.getInstance());
    }

    @FXML
    private TableView<Category> tableView;
    @FXML
    private Button geriBtn;
    @FXML
    private Button ekleBtn;
    @FXML
    private Button silBtn;
    @FXML
    private Button güncelleBtn;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        buildData();
        setCurrentUser((CurrentUser) FXRouter.getData());
        checkPermissions();
        setProperties();

    }

    private void checkPermissions() {
        try {
            var hasPermission = (UserPermission.getInstance(CurrentUser)).CanModifyCategory();
            if (!hasPermission) {
                ekleBtn.setVisible(false);
                güncelleBtn.setVisible(false);
                silBtn.setVisible(false);
            }
        } catch (Exception ex) {

            showAlert(Alert.AlertType.ERROR, "Yetki Kontrolü Başarısız", null, null);

        }

    }

    private void setProperties() {
        geriBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try {
                    FXRouter.goTo("anaekran", CurrentUser);
                    return;
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        });

        silBtn.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent actionEvent) {
                Category categoryDel=null;
                categoryDel=tableView.getSelectionModel().getSelectedItem();
                if(categoryDel==null){
                    showAlert(Alert.AlertType.WARNING,"Kategori Seçiniz",null,null);
                    return;
                }

                Category finalCategoryDel = categoryDel;
                Platform.runLater(()->{
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setHeaderText("Kategori Silinecek!");
                    alert.setTitle("Bilgi Kutusu");
                    alert.setContentText(finalCategoryDel.getName());

                    Optional<ButtonType> result =alert.showAndWait();

                    if(result.isEmpty()){
                        System.out.println("Alert Closed");
                    }else if (result.get()==ButtonType.OK){
                       DeleteKategori(finalCategoryDel);
                       return;
                    }
                });
            }
        });
        güncelleBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                Dialog<Category> categoryDialog = null;
                var category = tableView.getSelectionModel().getSelectedItem();
                if (category == null) {
                    showAlert(Alert.AlertType.WARNING, "Lütfen Kategori Seçiniz!", null, null);
                    return;
                }
                categoryDialog = new KategoriDialog(category);
                Optional<Category> result = categoryDialog.showAndWait();
                if (result.isPresent()) {
                    category.setName(result.get().getName());
                    _categoryRepository.update(category);
                    GetCategoryAndUpdateList();
                    return;
                }
            }
        });
        ekleBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                Dialog<Category> categoryDialog = null;
                categoryDialog = new KategoriDialog(null);
                Optional<Category> result = categoryDialog.showAndWait();
                if (result.isPresent()) {
                    Category yeni = result.get();
                    CheckIsCategoryExists(yeni);
                    _categoryRepository.add(yeni);
                    GetCategoryAddList(yeni);
                }
            }
        });
    }
    private void DeleteKategori(Category delCat){
        var categories=_categoryRepository.getAll();
        for (Category category:categories){
            if (category.getId()==delCat.getId()){
                _categoryRepository.delete(delCat.getId());
                RemoveFromTable(delCat);
                return;
            }
        }
        showAlert(Alert.AlertType.ERROR,"Kategory Bulunamadı!!", delCat.getName(), null);
    }

    private void RemoveFromTable(Category delCat) {
        var tableCat=tableView.getItems().filtered(category -> category.getId()==delCat.getId()).getFirst();
        tableView.getItems().remove(tableCat);
        tableView.refresh();
    }

    private void GetCategoryAndUpdateList() {
        var categories = _categoryRepository.getAll();
        _kategoriData=  FXCollections.observableArrayList();
        _kategoriData.addAll(categories);
        tableView.getItems().removeAll();
        tableView.setItems(_kategoriData);
        tableView.refresh();

    }

    private void GetCategoryAddList(Category yeni) {
        var categories = _categoryRepository.getAll();
        for (Category category : categories) {
            if (category.getName() == yeni.getName()) {
                yeni = category;
            }
        }
        tableView.getItems().add(yeni);
    }

    private void CheckIsCategoryExists(Category yeniCategory) {
        var categories = _categoryRepository.getAll();
        for (Category category : categories) {
            if (category.getName() == yeniCategory.getName()) {
                showAlert(Alert.AlertType.WARNING, "Kategori Mevcut", "Tekrar Deneyin!", null);
                return;
            }

        }
    }

    private void buildData() {
        var kategoriler = _categoryRepository.getAll();
        _kategoriData = FXCollections.observableArrayList();
        _kategoriData.addAll(kategoriler);
        var column1 = new TableColumn<Category, String>("ID");
        column1.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<Category, String>, ObservableValue<String>>() {
            public ObservableValue<String> call(TableColumn.CellDataFeatures<Category, String> param) {
                return new SimpleStringProperty(String.valueOf(param.getValue().getId()));
            }
        });
        column1.visibleProperty().set(false);

        var column2 = new TableColumn<Category, String>("Name");
        column2.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<Category, String>, ObservableValue<String>>() {
            public ObservableValue<String> call(TableColumn.CellDataFeatures<Category, String> param) {
                return new SimpleStringProperty(String.valueOf(param.getValue().getName()));
            }
        });

        tableView.getColumns().addAll(column1, column2);
        tableView.setItems(_kategoriData);
    }

}
