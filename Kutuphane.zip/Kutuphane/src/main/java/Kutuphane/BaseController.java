package Kutuphane;

import Helpers.SQLiteConnectionManager;
import Models.CurrentUser;
import Models.User;
import Repositories.UserRepository;
import javafx.application.Platform;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;

import java.net.URL;
import java.time.LocalDateTime;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.concurrent.Callable;

public  class BaseController implements Initializable {

    protected CurrentUser CurrentUser;
    protected SQLiteConnectionManager Context;
    public BaseController(){
        Context =SQLiteConnectionManager.getInstance();
        CurrentUser=null;
    }

    protected void setCurrentUser(CurrentUser user){
        CurrentUser=new CurrentUser();
        CurrentUser.setId(user.getId());
        CurrentUser.setPassword(user.getPassword());
        CurrentUser.setUserName(user.getUserName());
        CurrentUser.setRoleId(user.getRoleId());
        CurrentUser.setDate(LocalDateTime.now());
    }
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
    }
    public void showAlert(Alert.AlertType alertType, String text, String desc, Callable func){
        Platform.runLater(()->{
            Alert alert = new Alert(alertType);
            alert.setHeaderText(text);
            alert.setTitle("Bilgi Kutusu");
            alert.setContentText(desc);

            Optional<ButtonType> result =alert.showAndWait();

            if(result.isEmpty()){
                System.out.println("Alert Closed");
            }else if (result.get()==ButtonType.OK){
                try {
                    if(func !=null){
                        var r=func.call();
                    }
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        });
    }
}
