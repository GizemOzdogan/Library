package Kutuphane;

import Helpers.FXRouter;
import Helpers.SQLiteConnectionManager;
import Helpers.UserPermission;
import Models.BookStateTransaction;
import Models.CurrentUser;
import Models.User;
import Repositories.BookRepository;
import Repositories.BookStateTransactionRepository;
import Repositories.UserRepository;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.util.Callback;

import java.net.URL;
import java.util.ResourceBundle;

public class BookNotificationController extends BaseController {

    private UserRepository _userRepository;
    private BookRepository _bookRepository;
    private BookStateTransactionRepository _bookStateTransactionsRepository;

    @FXML
    private Button geriBtn;
    @FXML
    private Button isaretleBtn;

    @FXML
    private TableView<BookStateTransaction> tableView;

    private ObservableList<BookStateTransaction> _data;

    public BookNotificationController() {
        _bookStateTransactionsRepository = new BookStateTransactionRepository(SQLiteConnectionManager.getInstance());
        _userRepository = new UserRepository(SQLiteConnectionManager.getInstance());
        _bookRepository = new BookRepository(SQLiteConnectionManager.getInstance());
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        setCurrentUser((Models.CurrentUser) FXRouter.getData());
        checkPermissions();
        buildData();
        setCurrentUser((Models.CurrentUser) FXRouter.getData());
        setProperties();

    }

    private void setProperties() {
        geriBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try {
                    FXRouter.goTo("anaekran", CurrentUser);
                    return;
                } catch (Exception ex) {
                    System.out.println("Hatalı işlem");
                }
            }
        });

        isaretleBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                var selectedItem = tableView.getSelectionModel().getSelectedItem();
                if (selectedItem == null) {
                    showAlert(Alert.AlertType.WARNING, "Seçim Yapınız", null, null);
                    return;
                }

                var transaction = _bookStateTransactionsRepository.getById(selectedItem.getId());
                transaction.setRead(true);
                _bookStateTransactionsRepository.update(transaction);
                UpdateTable();
            }
        });
    }

    private void UpdateTable() {
        var trans = _bookStateTransactionsRepository.getAll();
        _data = FXCollections.observableArrayList();
        _data.addAll(trans);
        tableView.getItems().removeAll();
        tableView.setItems(_data);
        tableView.refresh();
    }

    private void buildData() {
        var bookTrans = _bookStateTransactionsRepository.getAll();
        _data = FXCollections.observableArrayList();
        _data.addAll(bookTrans);

        var column1 = new TableColumn<BookStateTransaction, String>("ID");
        column1.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<BookStateTransaction, String>, ObservableValue<String>>() {
            public ObservableValue<String> call(TableColumn.CellDataFeatures<BookStateTransaction, String> param) {
                return new SimpleStringProperty(String.valueOf(param.getValue().getId()));
            }
        });
        column1.visibleProperty().set(false);

        var column2 = new TableColumn<BookStateTransaction, String>("Durumu");
        column2.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<BookStateTransaction, String>, ObservableValue<String>>() {
            public ObservableValue<String> call(TableColumn.CellDataFeatures<BookStateTransaction, String> param) {
                return new SimpleStringProperty(String.valueOf(param.getValue().getStateName()));
            }
        });

        var column3 = new TableColumn<BookStateTransaction, String>("Önceki Durum");
        column3.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<BookStateTransaction, String>, ObservableValue<String>>() {
            public ObservableValue<String> call(TableColumn.CellDataFeatures<BookStateTransaction, String> param) {
                return new SimpleStringProperty(String.valueOf(param.getValue().getPreviousStateName()));
            }
        });


        var column6 = new TableColumn<BookStateTransaction, String>("Kullanıcı Adı");
        column6.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<BookStateTransaction, String>, ObservableValue<String>>() {
            public ObservableValue<String> call(TableColumn.CellDataFeatures<BookStateTransaction, String> param) {

                var user = _userRepository.getById(param.getValue().getUserId());
                var userName = "";
                if (user != null) {
                    userName = user.getUsername();
                }
                return new SimpleStringProperty(String.valueOf(userName));
            }
        });

        var column7 = new TableColumn<BookStateTransaction, String>("Kitap Adı");
        column7.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<BookStateTransaction, String>, ObservableValue<String>>() {
            public ObservableValue<String> call(TableColumn.CellDataFeatures<BookStateTransaction, String> param) {

                var kitap = _bookRepository.getById(param.getValue().getBookId());
                var bookName = "";
                if (kitap != null) {
                    bookName = kitap.getName();
                }
                return new SimpleStringProperty(String.valueOf(bookName));
            }
        });

        tableView.getColumns().addAll(column1, column2, column3, column6, column7);
        tableView.setItems(_data);
    }

    private void checkPermissions() {
        try {
            var hasPermission = (UserPermission.getInstance(CurrentUser)).CanCreateBookTransaction();
            if (!hasPermission) {
                isaretleBtn.setVisible(false);
            }
        } catch (Exception ex) {
            System.out.println("Yetkilendirme Hatası");
        }
    }
}
