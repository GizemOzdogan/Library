package Kutuphane;

import Application.KayitOlDialog;
import Helpers.FXRouter;
import Helpers.SQLiteConnectionManager;
import Models.BookStateTransaction;
import Models.CurrentUser;
import Models.User;
import Repositories.BookStateTransactionRepository;
import Repositories.UserRepository;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;

public class LoginController extends BaseController {

    public UserRepository _userRepository;
    private BookStateTransactionRepository _notifications;

    public LoginController() {
        _userRepository = new UserRepository(Context);
        _notifications = new BookStateTransactionRepository(SQLiteConnectionManager.getInstance());
    }

    @FXML
    private Label kullaniciAdi;
    @FXML
    private TextField kullaniciAdiTextField;
    @FXML
    private Label sifre;
    @FXML
    private TextField sifreTextField;
    @FXML
    private Button loginBtn;
    @FXML
    private Label kayitOl;
    @FXML
    private Button kayitOlBtn;


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        CheckNotifications();

        kullaniciAdi.setText("Kullanıcı Adı");
        sifre.setText("Şifre");
        loginBtn.setText("Giriş");
        kayitOl.setText("Kayit olmak için tıklayın");
        kayitOlBtn.setText("Kayıt Ol!!!");
        kayitOlBtn.setStyle("-fx-background-color: white");

        loginBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try {
                    LoginBtnClicked();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        });

        kayitOlBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                KayitOl();
                return;
            }
        });
    }

    private void CheckNotifications() {
        var publicNotifications = _notifications.getAll();
        var notification = publicNotifications.stream().filter(BookStateTransaction::getIsPublic).findFirst();
        if (notification.isPresent()) {
            showAlert(Alert.AlertType.INFORMATION, "Bildiri!", notification.get().getStateName(), null);
            notification.get().setRead(true);
            _notifications.update(notification.get());
            return;
        }
    }

    private void KayitOl() {
        Dialog<User> kayitOlDialog = null;
        kayitOlDialog = new KayitOlDialog(null);
        Optional<User> result = kayitOlDialog.showAndWait();
        if (result.isPresent()) {

            User user = result.get();
            if (!CheckUserNameExists(user)) {
                showAlert(Alert.AlertType.ERROR, "Kullanıcı Bulunmakta", user.getUsername(), null);
                return;
            }

            _userRepository.add(user);
            showAlert(Alert.AlertType.CONFIRMATION, "Kayit Başarılı", "Giriş yapınız..", null);
            return;

        }

    }

    private boolean CheckUserNameExists(User user) {
        var users = _userRepository.getAll();
        for (User u : users) {
            if (u.getUsername() == user.getUsername()) {
                return false;
            }
        }
        return true;
    }

    private User isUserExists(List<User> users) {
        for (int i = 0; i < users.size(); i++) {
            User user = users.get(i);
            if (user.getUsername().equals(kullaniciAdiTextField.getText()) && user.getPassword().equals(sifreTextField.getText())) {
                return user;
            }
        }
        return null;
    }

    private void LoginBtnClicked() throws IOException {

        var users = _userRepository.getAll();
        var user = isUserExists(users);
        if (user == null) {
            showAlert(Alert.AlertType.ERROR, "Giriş", "Giriş Başarısız Tekrar Deneyin!!!", null);
            return;
        }

        // route
        var currentUser = new CurrentUser();
        currentUser.setUserName(user.getUsername());
        currentUser.setId(user.getId());
        currentUser.setRoleId(user.getRoleId());
        currentUser.setPassword(user.getPassword());
        setCurrentUser(currentUser);
        FXRouter.goTo("anaekran", CurrentUser);
    }
}
