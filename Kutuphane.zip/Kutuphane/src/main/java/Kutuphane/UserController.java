package Kutuphane;

import Application.KategoriDialog;
import Application.RoleDialog;
import Helpers.FXRouter;
import Helpers.SQLiteConnectionManager;
import Helpers.UserPermission;
import Models.Category;
import Models.CurrentUser;
import Models.Role;
import Models.User;
import Repositories.RoleRepository;
import Repositories.UserRepository;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;
import javafx.util.Callback;

import java.net.URL;
import java.util.ArrayList;
import java.util.Objects;
import java.util.Optional;
import java.util.ResourceBundle;

public class UserController extends BaseController {
    private UserRepository _userRepository;
    private RoleRepository _roleRepository;

    public UserController() {
        _userRepository = new UserRepository(SQLiteConnectionManager.getInstance());
        _roleRepository = new RoleRepository(SQLiteConnectionManager.getInstance());
    }

    @FXML
    private TableView<User> tableView;
    @FXML
    private Button yetkiBtn;
    @FXML
    private Button silBtn;
    @FXML
    private Button geriBtn;
    private ObservableList<User> _data;
    @FXML
    private TextField filterText;
    @FXML
    private Button filterBtn;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        setCurrentUser((CurrentUser) FXRouter.getData());
        checkPermissions();
        buildData(null);
        setCurrentUser((Models.CurrentUser) FXRouter.getData());
        setProperties();

    }

    private void setProperties() {

        filterBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                if (filterText.getText() != null) {
                    buildData(filterText.getText());
                }
            }
        });
        geriBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try {
                    FXRouter.goTo("anaekran", CurrentUser);
                    return;
                } catch (Exception ex) {
                    System.out.println("Hata");
                }
            }
        });
        silBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {

                var user = tableView.getSelectionModel().getSelectedItem();
                if (user == null) {
                    showAlert(Alert.AlertType.WARNING, "İşlem Yapmak için Kullanıcı seçiniz", null, null);
                    return;
                }

                var dbUser = _userRepository.getById(user.getId());
                if (dbUser == null) {
                    showAlert(Alert.AlertType.WARNING, "kullanıcı bulunamadı", user.getUsername(), null);
                    return;
                }

                _userRepository.delete(dbUser.getId());
                UpdateTable();
            }
        });

        yetkiBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {

                var selectedUser = tableView.getSelectionModel().getSelectedItem();
                if (selectedUser == null) {
                    showAlert(Alert.AlertType.WARNING, "Kullanıcı Seçiniz..", null, null);
                    return;
                }

                Dialog<Role> roleDialog = null;
                roleDialog = new RoleDialog(null);
                Optional<Role> result = roleDialog.showAndWait();
                if (result.isPresent()) {
                    Role role = new Role();
                    var r = _roleRepository.getById(result.get().getId());
                    if (r == null) {
                        showAlert(Alert.AlertType.WARNING, "Role bulunamdı", null, null);
                        return;
                    }

                    selectedUser.setRoleId(r.getId());
                    _userRepository.update(selectedUser);
                    if (CurrentUser.getId() == selectedUser.getId()) {
                        CurrentUser.setRoleId(selectedUser.getRoleId());
                    }
                    UpdateTable();
                }
            }
        });
    }


    private void UpdateTable() {
        var users = _userRepository.getAll();
        _data = FXCollections.observableArrayList();
        _data.addAll(users);
        tableView.getItems().removeAll();
        tableView.setItems(_data);
        tableView.refresh();
    }

    private void checkPermissions() {
        try {
            var hasPermission = (UserPermission.getInstance(CurrentUser)).CanModifyUser();
            if (!hasPermission) {
                yetkiBtn.setVisible(false);
                silBtn.setVisible(false);
            }
        } catch (Exception ex) {
            System.out.println("Yetkilendirme Hatası");
        }
    }

    private void buildData(String filter) {

        var users = _userRepository.getAll();
        if (filter != null) {
            var filtredusers = new ArrayList<User>();
            for (User user : users) {
                if (user.getUsername().contains(filter) || user.getName().contains(filter)) {
                    filtredusers.add(user);
                }
            }
            users = filtredusers;
        }
        _data = FXCollections.observableArrayList();
        _data.addAll(users);

        var column1 = new TableColumn<User, String>("ID");
        column1.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<User, String>, ObservableValue<String>>() {
            public ObservableValue<String> call(TableColumn.CellDataFeatures<User, String> param) {
                return new SimpleStringProperty(String.valueOf(param.getValue().getId()));
            }
        });
        column1.visibleProperty().set(false);

        var column2 = new TableColumn<User, String>("Name");
        column2.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<User, String>, ObservableValue<String>>() {
            public ObservableValue<String> call(TableColumn.CellDataFeatures<User, String> param) {
                return new SimpleStringProperty(String.valueOf(param.getValue().getName()));
            }
        });

        var column3 = new TableColumn<User, String>("UserName");
        column3.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<User, String>, ObservableValue<String>>() {
            public ObservableValue<String> call(TableColumn.CellDataFeatures<User, String> param) {
                return new SimpleStringProperty(String.valueOf(param.getValue().getUsername()));
            }
        });

        var column4 = new TableColumn<User, String>("Şifre");
        column4.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<User, String>, ObservableValue<String>>() {
            public ObservableValue<String> call(TableColumn.CellDataFeatures<User, String> param) {
                return new SimpleStringProperty(String.valueOf(param.getValue().getPassword()));
            }
        });

        var column5 = new TableColumn<User, String>("Rol");
        column5.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<User, String>, ObservableValue<String>>() {
            public ObservableValue<String> call(TableColumn.CellDataFeatures<User, String> param) {
                var role = _roleRepository.getById(param.getValue().getRoleId());
                return new SimpleStringProperty(String.valueOf(role.getName()));
            }
        });

        tableView.getColumns().addAll(column1, column2, column3, column4, column5);
        tableView.setItems(_data);
    }

}
