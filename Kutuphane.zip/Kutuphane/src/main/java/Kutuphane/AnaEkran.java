package Kutuphane;

import Application.BookDialog;
import Helpers.FXRouter;
import Helpers.UserPermission;
import Models.Book;
import Models.BookStateTransaction;
import Models.CurrentUser;
import Repositories.BookRepository;
import Repositories.BookStateTransactionRepository;
import Repositories.CategoryRepository;
import States.AvailableState;
import States.BookState;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.util.Callback;

import java.io.IOException;
import java.net.URL;
import java.sql.Date;
import java.time.LocalDate;
import java.util.*;

public class AnaEkran extends BaseController {

    @FXML
    private TableView<Book> tableView;
    private ObservableList<Book> data;
    private UserPermission _userPermission;
    private BookRepository _bookRepository;
    private CategoryRepository _categoryRepository;
    private BookStateTransactionRepository bookStateTransactionRepository;

    public AnaEkran() {
        _bookRepository = new BookRepository(Context);
        _categoryRepository = new CategoryRepository(Context);
        bookStateTransactionRepository = new BookStateTransactionRepository(Context);
        tableView = new TableView<Book>();
    }

    @FXML
    private Button cikisBtn;
    @FXML
    private Button notifyLostBtn;
    @FXML
    private Button notifyFoundBtn;
    @FXML
    private Button notifyBorrowBtn;
    @FXML
    private Button notifyReturnBtn;
    @FXML
    private Button notifyAll;
    @FXML
    private Button categoryRouteBtn;
    @FXML
    private Button userListBtn;
    @FXML
    private Button notificationBtn;

    @FXML
    private TextField filterField;
    @FXML
    private Button filterBtn;
    @FXML
    private Button silBtn;
    @FXML
    private Button güncelleBtn;
    @FXML
    private Button ekleBtn;

    public void initialize(URL url, ResourceBundle resourceBundle) {
        SetUser();
        CheckNotifyPermission();
        CheckUserListPermission();
        CheckBookModifierPermission();
        CheckNotifyBookTransactionPermission();
        buildData(null);
        setProperties();
    }

    private void CheckBookModifierPermission() {
        try {
            var hasPermissionToNotifyAll = _userPermission.CanModifyBook();
            if (!hasPermissionToNotifyAll) {
                silBtn.setVisible(false);
                güncelleBtn.setVisible(false);
                ekleBtn.setVisible(false);
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private void CheckNotifyBookTransactionPermission(){
        try {
            var isStudent = _userPermission.IsStudent();
            var isTeacher = _userPermission.IsTeacher();
            var isPersonnel = _userPermission.IsPersonnel();

            if(isStudent || isTeacher){
                notifyLostBtn.setVisible(false);
                notifyFoundBtn.setVisible(false);
                notifyBorrowBtn.setVisible(true);
                notifyReturnBtn.setVisible(true);
            }

            if(isPersonnel){
                notifyLostBtn.setVisible(true);
                notifyFoundBtn.setVisible(true);
                notifyBorrowBtn.setVisible(false);
                notifyReturnBtn.setVisible(false);
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    private void CheckNotifyPermission() {
        try {
            var hasPermissionToNotifyAll = _userPermission.CanNotifyAllTransaction();
            if (!hasPermissionToNotifyAll) {
                notifyAll.setVisible(false);
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private void CheckUserListPermission() {
        try {
            var hasPermissionToNotifyAll = _userPermission.CanModifyUser();
            if (!hasPermissionToNotifyAll) {
                userListBtn.setVisible(false);
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    private void setProperties() {

        notifyBorrowBtn.setText("Ödünç Al");
        notifyFoundBtn.setText("Bulundu");
        notifyLostBtn.setText("Kaybedildi");
        notifyReturnBtn.setText("Getirildi");
        notifyAll.setText("Anons!");
        categoryRouteBtn.setText("Kategoriler");
        notifyAll.setVisible(false);

        notifyBorrowBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                var selectedBook = tableView.getSelectionModel().getSelectedItem();
                if (selectedBook == null) {
                    showAlert(Alert.AlertType.WARNING, "Kitap seçiniz", null, null);
                    return;
                }

                try {
                    var state = BookState.createBookState(selectedBook);
                    state.borrow();
                    _bookRepository.update(selectedBook);
                    var newState = new BookStateTransaction(0, "Boşta", "Ödünç Alındı", CurrentUser.getId(), selectedBook.getId(), Date.valueOf(LocalDate.now()), false, false);
                    bookStateTransactionRepository.add(newState);
                    UpdateTable();
                } catch (Exception ex) {
                    showAlert(Alert.AlertType.ERROR, "Hata", ex.getMessage(), null);
                    return;
                }
            }
        });

        notifyFoundBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                var selectedBook = tableView.getSelectionModel().getSelectedItem();
                if (selectedBook == null) {
                    showAlert(Alert.AlertType.WARNING, "Kitap seçiniz", null, null);
                    return;
                }

                try {
                    var state = BookState.createBookState(selectedBook);
                    state.found();
                    _bookRepository.update(selectedBook);
                    var newState = new BookStateTransaction(0, "Kayıp", "Bulundu", CurrentUser.getId(), selectedBook.getId(), Date.valueOf(LocalDate.now()), false, false);
                    bookStateTransactionRepository.add(newState);
                    UpdateTable();
                } catch (Exception ex) {
                    showAlert(Alert.AlertType.ERROR, "Hata", ex.getMessage(), null);
                    return;
                }
            }
        });

        notifyReturnBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                var selectedBook = tableView.getSelectionModel().getSelectedItem();
                if (selectedBook == null) {
                    showAlert(Alert.AlertType.WARNING, "Kitap seçiniz", null, null);
                    return;
                }

                try {
                    var state = BookState.createBookState(selectedBook);
                    state.returnBook();
                    _bookRepository.update(selectedBook);
                    var newState = new BookStateTransaction(0, "Ödünç Alındı", "İade Edildi", CurrentUser.getId(), selectedBook.getId(), Date.valueOf(LocalDate.now()), false, false);
                    bookStateTransactionRepository.add(newState);
                    UpdateTable();
                } catch (Exception ex) {
                    showAlert(Alert.AlertType.ERROR, "Hata", ex.getMessage(), null);
                    return;
                }
            }
        });

        notifyLostBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                var selectedBook = tableView.getSelectionModel().getSelectedItem();
                if (selectedBook == null) {
                    showAlert(Alert.AlertType.WARNING, "Kitap seçiniz", null, null);
                    return;
                }

                try {
                    var state = BookState.createBookState(selectedBook);
                    state.lose();
                    _bookRepository.update(selectedBook);
                    var newState = new BookStateTransaction(0, "Ödünç Alındı", "Kaybedildi", CurrentUser.getId(), selectedBook.getId(), Date.valueOf(LocalDate.now()), false, false);
                    bookStateTransactionRepository.add(newState);
                    UpdateTable();
                } catch (Exception ex) {
                    showAlert(Alert.AlertType.ERROR, "Hata", ex.getMessage(), null);
                    return;
                }

            }
        });

        notificationBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try {
                    FXRouter.goTo("kitapbildirimleri", CurrentUser);
                    return;
                } catch (Exception ex) {
                    System.out.println("Hatalı işlem");
                }
            }
        });
        cikisBtn.setText("Çıkış Yap");
        cikisBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try {
                    Cikis();
                    return;
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        });

        categoryRouteBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try {
                    FXRouter.goTo("kategoriliste", CurrentUser);
                    return;
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        });

        userListBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try {
                    FXRouter.goTo("kullaniciliste", CurrentUser);
                    return;
                } catch (Exception ex) {
                    System.out.println("Ex");
                }

            }
        });

        filterBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                var textFieldValue = filterField.getText();
                if (textFieldValue == null) {
                    return;
                }
                buildData(textFieldValue);
            }
        });

        silBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                var selectedItem = tableView.getSelectionModel().getSelectedItem();
                if (selectedItem == null) {
                    showAlert(Alert.AlertType.WARNING, "Lütfen Seçim Yapınız", null, null);
                    return;
                }

                var book = _bookRepository.getById(selectedItem.getId());
                _bookRepository.delete(book.getId());
                UpdateTable();
            }
        });

        güncelleBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {

                var selectedBook = tableView.getSelectionModel().getSelectedItem();
                Dialog<Book> bookDialog = null;
                bookDialog = new BookDialog(selectedBook);
                Optional<Book> result = bookDialog.showAndWait();
                if (result.isPresent()) {
                    Book book = result.get();
                    _bookRepository.update(book);
                    showAlert(Alert.AlertType.CONFIRMATION, "Güncelleme Başarılı", null, null);
                    UpdateTable();
                }
            }
        });
        ekleBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                Dialog<Book> bookDialog = null;
                bookDialog = new BookDialog(null);
                Optional<Book> result = bookDialog.showAndWait();
                if (result.isPresent()) {

                    Book book = result.get();
                    _bookRepository.add(book);
                    showAlert(Alert.AlertType.CONFIRMATION, "Kayit Başarılı", null, null);
                    UpdateTable();
                }
            }
        });
    }

    private void UpdateTable() {
        var trans = _bookRepository.getAll();
        data = FXCollections.observableArrayList();
        data.addAll(trans);
        tableView.getItems().removeAll();
        tableView.setItems(data);
        tableView.refresh();
    }

    private void SetUser() {
        setCurrentUser((CurrentUser) FXRouter.getData()); // önceki veriyi al
        _userPermission = UserPermission.getInstance(CurrentUser);
    }

    public void buildData(String filterVal) {
        List<Book> books = _bookRepository.getAll();
        if (filterVal != null) {
            List<Book> filtredBooks = new ArrayList<Book>();
            for (Book book : books) {
                if (book.getName().contains(filterVal) || book.getAuthor().contains(filterVal)) {
                    filtredBooks.add(book);
                }
            }
            books = filtredBooks;
        }

        data = FXCollections.observableArrayList();

        data.addAll(books);

        //Set column properties
        TableColumn column1 = new TableColumn("Id");
        column1.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<Book, String>, ObservableValue<String>>() {
            public ObservableValue<String> call(TableColumn.CellDataFeatures<Book, String> param) {
                return new SimpleStringProperty(String.valueOf(param.getValue().getId()));
            }
        });
        column1.visibleProperty().set(false);

        TableColumn column2 = new TableColumn("Name");
        column2.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<Book, String>, ObservableValue<String>>() {
            public ObservableValue<String> call(TableColumn.CellDataFeatures<Book, String> param) {
                return new SimpleStringProperty(param.getValue().getName());
            }
        });

        TableColumn column3 = new TableColumn("Author");
        column3.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<Book, String>, ObservableValue<String>>() {
            public ObservableValue<String> call(TableColumn.CellDataFeatures<Book, String> param) {
                return new SimpleStringProperty(param.getValue().getAuthor());
            }
        });

        TableColumn column4 = new TableColumn("Category");
        column4.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<Book, String>, ObservableValue<String>>() {
            public ObservableValue<String> call(TableColumn.CellDataFeatures<Book, String> param) {
                var category = _categoryRepository.getById(param.getValue().getCategoryId());
                return new SimpleStringProperty(category.getName());
            }
        });

        TableColumn column5 = new TableColumn("BookState");
        column5.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<Book, String>, ObservableValue<String>>() {

            public ObservableValue<String> call(TableColumn.CellDataFeatures<Book, String> param) {
                return new SimpleStringProperty(param.getValue().State.toString());
            }
        });

        tableView.getColumns().addAll(column1, column2, column3, column4, column5);
        tableView.setItems(data);

    }

    private void Cikis() throws IOException {
        CurrentUser = null;
        FXRouter.goTo("giris");
    }

}
