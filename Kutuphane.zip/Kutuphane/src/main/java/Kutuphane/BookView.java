package Kutuphane;

import Models.Book;
import States.BookState;
import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.stage.Stage;

public class BookView extends Application {
    TableView<Book> table =new TableView<Book>();
    @Override
    public void start(Stage stage) throws Exception {
        Group group = new Group();

        TableColumn id = new TableColumn("ID");
        TableColumn name =new TableColumn("NAME");
        TableColumn ISBN =new TableColumn("ISBN");
        TableColumn author = new TableColumn("AUTHOR");
        TableColumn category = new TableColumn("CATEGORY");
        TableColumn bookState = new TableColumn("BOOKSTATE");

        table.getColumns().addAll(id,name,ISBN,author,category,bookState);

        Scene scene=new Scene(group,400,600);

        scene.getRoot().getChildrenUnmodifiable().add(table);

        stage.setTitle("Books");
        stage.setScene(scene);
        stage.show();
    }
}
