package Kutuphane;

import Helpers.FXRouter;
import Helpers.SQLiteConnectionManager;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.util.ResourceBundle;

public class KutuphaneApp extends Application {
    @Override
    public void start(Stage stage) throws Exception {

        var baseDbInstance =SQLiteConnectionManager.getInstance();
        baseDbInstance.createDatabaseIfNotExists();

        FXMLLoader loader = new  FXMLLoader(getClass().getResource("Kutuphane.fxml"));
        Parent root =loader.load();
        Scene scene=new Scene(root);
        stage.setScene(scene);
        FXRouter.bind(this,stage,"Kutuphane.fxml",600,400);
        FXRouter.when("giris","Kutuphane.fxml","Giriş",600,400);
        FXRouter.when("anaekran","AnaEkran.fxml","Ana Ekran",600,400);
        FXRouter.when("kategoriliste","KategoriList.fxml","Kategoriler",600,400);
        FXRouter.when("kullaniciliste","UserList.fxml","Kullanıcılar",600,400);
        FXRouter.when("kitapbildirimleri","BookNotification.fxml","Bildiriler",600,400);
        FXRouter.setAnimationType("fade");

        stage.show();
    }

    public static void main(String[] args){
        launch(args);
    }
}
