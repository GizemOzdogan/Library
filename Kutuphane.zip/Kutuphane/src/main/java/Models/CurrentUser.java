package Models;

import java.time.LocalDateTime;
import java.util.Date;

public class CurrentUser{
    private int Id;
    private String UserName;
    private String Password;
    private int RoleId;
    private LocalDateTime date;

    public CurrentUser(){
        //default
    }
    public int getRoleId() {
        return RoleId;
    }

    public void setRoleId(int roleId) {
        RoleId = roleId;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String password) {
        Password = password;
    }

    public String getUserName() {
        return UserName;
    }

    public void setUserName(String userName) {
        UserName = userName;
    }

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

    public LocalDateTime getDate() {
        return date;
    }

    public void setDate(LocalDateTime date) {
        this.date = date;
    }
}
