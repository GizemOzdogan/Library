package Models;

import java.util.Date;

public class InventoryNotification {
    private int id;
    private String bookName;
    private int userId;
    private Date notificationDate;
    private int isRead;
    private Date readDate;

    public InventoryNotification() {
        // Default constructor
    }

    public InventoryNotification(int id, String bookName, int userId, Date notificationDate, int isRead, Date readDate) {
        this.id = id;
        this.bookName = bookName;
        this.userId = userId;
        this.notificationDate = notificationDate;
        this.isRead = isRead;
        this.readDate = readDate;
    }

    // Getter and setter methods
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getBookName() {
        return bookName;
    }

    public void setBookName(String bookName) {
        this.bookName = bookName;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public Date getNotificationDate() {
        return notificationDate;
    }

    public void setNotificationDate(Date notificationDate) {
        this.notificationDate = notificationDate;
    }

    public int getIsRead() {
        return isRead;
    }

    public void setIsRead(int isRead) {
        this.isRead = isRead;
    }

    public Date getReadDate() {
        return readDate;
    }

    public void setReadDate(Date readDate) {
        this.readDate = readDate;
    }
}
