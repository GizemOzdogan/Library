package Models;

import States.BookState;

public class Book {
    private int id;
    private String name;
    private String ISBN;
    private String author;
    private int categoryId;
    private int bookState;
    public BookState State;

    public Book() {
        // Default constructor
    }

    public Book(int id, String name, String ISBN, String author, int categoryId, int bookState) {
        this.id = id;
        this.name = name;
        this.ISBN = ISBN;
        this.author = author;
        this.categoryId = categoryId;
        this.bookState = bookState;
        this.State = BookState.createBookState(this);
    }

    // Getter and setter methods
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getISBN() {
        return ISBN;
    }

    public void setISBN(String ISBN) {
        this.ISBN = ISBN;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public int getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(int categoryId) {
        this.categoryId = categoryId;
    }

    public int getBookState() {
        return bookState;
    }

    public void setBookState(int bookState) {
        this.bookState = bookState;
    }
}
