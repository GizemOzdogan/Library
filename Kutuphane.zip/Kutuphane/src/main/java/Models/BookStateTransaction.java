package Models;

import java.util.Date;

public class BookStateTransaction {
    private int id;
    private String previousStateName;
    private String stateName;
    private int userId;
    private int bookId;
    private Date transactionDate;
    private boolean isRead;
    private boolean isPublic;

    public BookStateTransaction() {
        // Default constructor
    }

    public BookStateTransaction(int id, String previousStateName, String stateName, int userId, int bookId, Date transactionDate, boolean isRead, boolean isPublic) {
        this.id = id;
        this.previousStateName = previousStateName;
        this.stateName = stateName;
        this.userId = userId;
        this.bookId = bookId;
        this.transactionDate = transactionDate;
        this.isRead = isRead;
        this.isPublic = isPublic;
    }

    // Getter and setter methods
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPreviousStateName() {
        return previousStateName;
    }

    public void setPreviousStateName(String previousStateName) {
        this.previousStateName = previousStateName;
    }

    public String getStateName() {
        return stateName;
    }

    public void setStateName(String stateName) {
        this.stateName = stateName;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getBookId() {
        return bookId;
    }

    public void setBookId(int bookId) {
        this.bookId = bookId;
    }

    public Date getTransactionDate() {
        return transactionDate;
    }

    public void setTransactionDate(Date transactionDate) {
        this.transactionDate = transactionDate;
    }

    public boolean getIsPublic() {return isPublic;}

    public void setPublic(boolean aPublic) {
        isPublic = aPublic;
    }

    public boolean getIsRead() {
        return isRead;
    }

    public void setRead(boolean read) {
        isRead = read;
    }
}
