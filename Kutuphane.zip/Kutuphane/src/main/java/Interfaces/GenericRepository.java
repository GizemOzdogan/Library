package Interfaces;

import java.util.List;

public interface GenericRepository<T> {
    void add(T entity);
    T getById(int id);
    List<T> getAll();
    void update(T entity);
    void delete(int id);
    List<T> query(String sql);
    boolean exists(int id);
    int count();
    int count(String sql);
}

