package Application;

import Helpers.SQLiteConnectionManager;
import Models.Category;
import Models.Role;
import Repositories.RoleRepository;
import javafx.beans.property.SimpleStringProperty;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.util.Callback;

import java.util.ArrayList;

public class RoleDialog extends Dialog<Role> {

    private RoleRepository _roleRepository;
    private Role role;
    private ChoiceBox<String> nameField;

    public RoleDialog(Role role) {
        super();
        _roleRepository=new RoleRepository(SQLiteConnectionManager.getInstance());
        this.setTitle("Role ver");
        this.role = role == null ? new Role() : role;
        buildUI();
        setPropertyBindings();
        setResultConverter();
    }

    private void setResultConverter() {

        Callback<ButtonType, Role> result = new Callback<ButtonType, Role>() {
            @Override
            public Role call(ButtonType buttonType) {
                if (buttonType == ButtonType.OK) {
                    var c=new Role();
                    var selectedIndex=nameField.getSelectionModel().getSelectedIndex();
                    c.setId(selectedIndex+1);
                    return c;
                } else {
                    return null;
                }
            }
        };
        setResultConverter(result);
    }
    private void setPropertyBindings() {

    }

    private Pane buildUI() {
        VBox content = new VBox(10);

        Label name = new Label("Rol Adı");
        this.nameField = new ChoiceBox<String>();
        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(5);
        grid.add(name, 0, 0);
        this.nameField=new ChoiceBox<String>();
        var roles=_roleRepository.getAll();
        var roleNames=new ArrayList<String>();
        for (Role r:roles){
            roleNames.add(r.getName());
        }
        nameField.getItems().addAll(roleNames);
        grid.add(nameField, 1, 0);
        GridPane.setHgrow(this.nameField, Priority.ALWAYS);
        content.getChildren().add(grid);
        getDialogPane().setContent(content);
        getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        Button ok = (Button) getDialogPane().lookupButton(ButtonType.OK);
        ok.addEventFilter(ActionEvent.ACTION, new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                if (!validateDialog()) {
                    actionEvent.consume();
                }
            }

            private boolean validateDialog() {
                if (nameField.getSelectionModel().isEmpty()) {
                    return false;
                }
                return true;
            }
        });

        return content;
    }

}
