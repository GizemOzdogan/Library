package Application;

import Helpers.SQLiteConnectionManager;
import Models.Book;
import Models.Category;
import Models.Role;
import Repositories.CategoryRepository;
import javafx.beans.property.SimpleStringProperty;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.util.Callback;

import java.util.ArrayList;

public class BookDialog extends Dialog<Book> {

    private Book book;
    private TextField bookNameTextField;
    private TextField autherTextField;
    private ChoiceBox<String> Kategori;
    private CategoryRepository _categoryRepository;

    public BookDialog(Book book) {
        super();

        var title = "Kitap Ekle";
        if (book != null) {
            title = "Kitap Güncelle";
        }
        this.setTitle(title);
        this.book = book == null ? new Book() : book;
        buildUI();
        setPropertyBindings();
        setResultConverter();

    }

    private void setResultConverter() {

        Callback<ButtonType, Book> result = new Callback<ButtonType, Book>() {
            @Override
            public Book call(ButtonType buttonType) {
                if (buttonType == ButtonType.OK) {

                    var selectedCategoryName = Kategori.getSelectionModel().getSelectedItem();
                    var categories = _categoryRepository.getAll();
                    var categoryObject = categories.stream().filter(category1 -> {
                        return category1.getName().equals(selectedCategoryName);
                    }).findFirst();
                    if (categoryObject.isPresent()) {
                        var c = new Book();
                        c.setId(book.getId());
                        c.setISBN("");
                        c.setCategoryId(categoryObject.get().getId());
                        c.setName(bookNameTextField.getText());
                        c.setAuthor(autherTextField.getText());
                        c.setBookState(1);
                        return c;
                    }
                } else {
                    return null;
                }
                return null;
            }
        };
        setResultConverter(result);
    }

    private void setPropertyBindings() {
        bookNameTextField.textProperty().bindBidirectional(new SimpleStringProperty(book.getName()));
        autherTextField.textProperty().bindBidirectional(new SimpleStringProperty(book.getAuthor()));

    }

    private Pane buildUI() {
        VBox content = new VBox(10);

        Label password = new Label("Yazar Adı");
        Label bookName = new Label("Kitap Adı");
        Label category_name = new Label("Kategori seçin..");
        this.bookNameTextField = new TextField();
        this.autherTextField = new TextField();
        this.Kategori = new ChoiceBox<String>();
        _categoryRepository = new CategoryRepository(SQLiteConnectionManager.getInstance());
        var categories = _categoryRepository.getAll();
        var categoriNames = new ArrayList<String>();
        for (Category r : categories) {
            categoriNames.add(r.getName());
        }
        Kategori.getItems().addAll(categoriNames);
        if (book != null && book.getCategoryId() > 0) {
            var category = _categoryRepository.getById(book.getCategoryId());
            Kategori.setValue(category.getName());

        }

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(5);
        grid.add(password, 0, 0);
        grid.add(autherTextField, 0, 1);
        grid.add(bookName, 1, 0);
        grid.add(bookNameTextField, 1, 1);
        grid.add(category_name, 2, 0);
        grid.add(Kategori, 2, 1);
        GridPane.setHgrow(this.bookNameTextField, Priority.ALWAYS);
        GridPane.setHgrow(this.autherTextField, Priority.ALWAYS);
        GridPane.setHgrow(this.Kategori, Priority.ALWAYS);
        content.getChildren().add(grid);
        getDialogPane().setContent(content);
        getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        Button ok = (Button) getDialogPane().lookupButton(ButtonType.OK);
        ok.addEventFilter(ActionEvent.ACTION, new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                if (!validateDialog()) {
                    actionEvent.consume();
                }
            }

            private boolean validateDialog() {
                if (bookNameTextField.getText().isEmpty()) {
                    return false;
                }
                if (autherTextField.getText().isEmpty()) {
                    return false;
                }

                if (Kategori.getSelectionModel().isEmpty()) {
                    return false;
                }
                return true;
            }
        });

        return content;
    }
}
