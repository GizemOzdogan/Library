package Application;

import Helpers.SQLiteConnectionManager;
import Models.Role;
import Models.User;
import Repositories.RoleRepository;
import javafx.beans.property.SimpleStringProperty;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.util.Callback;

import java.util.ArrayList;

public class KayitOlDialog extends Dialog<User> {

    private User user;
    private TextField userNameTextField;
    private TextField passwordTextField;
    private TextField nameTextField;
    private ChoiceBox<String> Roles;
    private RoleRepository _roleRepository;

    public KayitOlDialog(User user) {
        super();

        var title = "Kullanıcı Ekle";
        if (user != null) {
            title = "Kullanıcı Güncelle";
        }
        this.setTitle(title);
        this.user = user == null ? new User() : user;
        buildUI();
        setPropertyBindings();
        setResultConverter();

    }

    private void setResultConverter() {

        Callback<ButtonType, User> result = new Callback<ButtonType, User>() {
            @Override
            public User call(ButtonType buttonType) {
                if (buttonType == ButtonType.OK) {

                    var selectedRoleIndex=Roles.getSelectionModel().getSelectedIndex();
                    var selectedRole=_roleRepository.getById(selectedRoleIndex+1);
                    var c=new User();
                    c.setId(user.getId());
                    c.setUsername(userNameTextField.getText());
                    c.setPassword(passwordTextField.getText());
                    c.setName(nameTextField.getText());
                    c.setRoleId(selectedRole.getId());
                    return c;
                } else {
                    return null;
                }
            }
        };
        setResultConverter(result);
    }
    private void setPropertyBindings() {
        userNameTextField.textProperty().bindBidirectional(new SimpleStringProperty(user.getUsername()));
        passwordTextField.textProperty().bindBidirectional(new SimpleStringProperty(user.getPassword()));
        nameTextField.textProperty().bindBidirectional(new SimpleStringProperty(user.getName()));
    }

    private Pane buildUI() {
        VBox content = new VBox(10);

        Label name = new Label("Adınız");
        Label password = new Label("Şifre");
        Label userName = new Label("Kullanıcı Adı");
        Label role=new Label("Role seçin..");
        this.userNameTextField = new TextField();
        this.passwordTextField = new TextField();
        this.nameTextField = new TextField();
        this.Roles=new ChoiceBox<String>();
        _roleRepository=new RoleRepository(SQLiteConnectionManager.getInstance());
        var roles=_roleRepository.getAll();
        var roleNames=new ArrayList<String>();
        for (Role r:roles){
            roleNames.add(r.getName());
        }
        Roles.getItems().addAll(roleNames);

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(5);
        grid.add(name, 0, 0);
        grid.add(nameTextField, 0, 1);
        grid.add(password,1,0);
        grid.add(passwordTextField, 1, 1);
        grid.add(userName,2,0);
        grid.add(userNameTextField,2,1);
        grid.add(role,3,0);
        grid.add(Roles, 3, 1);
        GridPane.setHgrow(this.userNameTextField, Priority.ALWAYS);
        GridPane.setHgrow(this.passwordTextField, Priority.ALWAYS);
        GridPane.setHgrow(this.nameTextField, Priority.ALWAYS);
        GridPane.setHgrow(this.Roles, Priority.ALWAYS);
        content.getChildren().add(grid);
        getDialogPane().setContent(content);
        getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        Button ok = (Button) getDialogPane().lookupButton(ButtonType.OK);
        ok.addEventFilter(ActionEvent.ACTION, new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                if (!validateDialog()) {
                    actionEvent.consume();
                }
            }

            private boolean validateDialog() {
                if (userNameTextField.getText().isEmpty()) {
                    return false;
                }
                if(passwordTextField.getText().isEmpty()){
                    return false;
                }

                if(nameTextField.getText().isEmpty()){
                    return false;
                }

                if(Roles.getSelectionModel().isEmpty()){
                    return false;
                }
                return true;
            }
        });

        return content;
    }
}
