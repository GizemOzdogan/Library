package Application;

import Models.Category;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.util.Callback;

import java.io.IOException;

public class KategoriDialog extends Dialog<Category> {

    private Category category;
    private TextField nameField;

    public KategoriDialog(Category category) {
        super();

        var title = "Kategori Ekle";
        if (category != null) {
            title = "Kategori Güncelle";
        }
        this.setTitle(title);
        this.category = category == null ? new Category() : category;
        buildUI();
        setPropertyBindings();
        setResultConverter();
    }

    private void setResultConverter() {

        Callback<ButtonType, Category> result = new Callback<ButtonType, Category>() {
            @Override
            public Category call(ButtonType buttonType) {
                if (buttonType == ButtonType.OK) {
                    var c=new Category();
                    c.setId(category.getId());
                    c.setName(nameField.getText());
                    return c;
                } else {
                    return null;
                }
            }
        };
        setResultConverter(result);
    }
    private void setPropertyBindings() {
        nameField.textProperty().bindBidirectional(new SimpleStringProperty(category.getName()));
    }

    private Pane buildUI() {
        VBox content = new VBox(10);

        Label name = new Label("Kategori Adı");
        this.nameField = new TextField();
        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(5);
        grid.add(name, 0, 0);
        grid.add(nameField, 1, 0);
        GridPane.setHgrow(this.nameField, Priority.ALWAYS);
        content.getChildren().add(grid);
        getDialogPane().setContent(content);
        getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        Button ok = (Button) getDialogPane().lookupButton(ButtonType.OK);
        ok.addEventFilter(ActionEvent.ACTION, new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                if (!validateDialog()) {
                    actionEvent.consume();
                }
            }

            private boolean validateDialog() {
                if (nameField.getText().isEmpty()) {
                    return false;
                }
                return true;
            }
        });

        return content;
    }

}
