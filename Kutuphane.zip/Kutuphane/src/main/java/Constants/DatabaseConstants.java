package Constants;

import java.sql.Date;

public class DatabaseConstants {
    private static final String UserHomePath = System.getProperty("user.home");
    private static final String RunningPath = System.getProperty("user.dir");

    private static final String DB_NAME = "Kutuphane.db";
    public static final String DB_URL = "jdbc:sqlite:" + RunningPath + "\\" + DB_NAME;
    public static final String DB_INIT_SCRIPT_PATH = "src/main/resources/DatabaseInitScript.sql";

}