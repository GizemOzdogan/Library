CREATE TABLE User (
                      Id INTEGER PRIMARY KEY AUTOINCREMENT,
                      Name TEXT,
                      Username TEXT,
                      Password TEXT,
                      RoleId INTEGER,
                      FOREIGN KEY (RoleId) REFERENCES Role (Id)
);

CREATE TABLE Role (
                      Id INTEGER PRIMARY KEY AUTOINCREMENT,
                      Name TEXT
);

CREATE TABLE Book (
                      Id INTEGER PRIMARY KEY AUTOINCREMENT,
                      Name TEXT,
                      ISBN TEXT,
                      Author TEXT,
                      CategoryId INTEGER,
                      BookState INTEGER,
                      FOREIGN KEY (CategoryId) REFERENCES Category (Id)
);

CREATE TABLE Category (
                          Id INTEGER PRIMARY KEY AUTOINCREMENT,
                          Name TEXT
);

CREATE TABLE BookStateTransaction (
                                      Id INTEGER PRIMARY KEY AUTOINCREMENT,
                                      PreviousStateName TEXT,
                                      StateName TEXT,
                                      UserId INTEGER,
                                      BookId INTEGER,
                                      TransactionDate DATE,
                                      IsRead BOOLEAN,
                                      IsPublic BOOLEAN,
                                      FOREIGN KEY (BookId) REFERENCES Book (Id),
                                      FOREIGN KEY (UserId) REFERENCES User (Id)
);

CREATE TABLE InventoryNotification (
                                       Id INTEGER PRIMARY KEY AUTOINCREMENT,
                                       BookName TEXT,
                                       UserId INTEGER,
                                       NotificationDate DATE,
                                       IsRead INTEGER,
                                       ReadDate DATE,
                                       FOREIGN KEY (UserId) REFERENCES User (Id)
);


Insert into Role (Name) values ('Personel');
Insert into Role (Name) values ('Öğretim Görevlisi');
Insert into Role (Name) values ('Öğrenci');

Insert into User (Name, Username, Password, RoleId) values ('Personel', 'personel', 'personel', 1);
Insert into User (Name, Username, Password, RoleId) values ('Öğretim Görevlisi', 'ogretim', 'ogretim', 2);
Insert into User (Name, Username, Password, RoleId) values ('Öğrenci', 'ogrenci', 'ogrenci', 3);

Insert into Category (Name) values ('Bilgisayar');
Insert into Category (Name) values ('Mühendislik');
Insert into Category (Name) values ('Tarih');


Insert into Book (Name, ISBN, Author, CategoryId, BookState) values ('Bilgisayar Mühendisliğine Giriş', '123456789', 'Yazar 1', 1, 1);
Insert into Book (Name, ISBN, Author, CategoryId, BookState) values ('Mühendislik', '123456789', 'Yazar 2', 2, 1);
Insert into Book (Name, ISBN, Author, CategoryId, BookState) values ('Tarih', '123456789', 'Yazar 3', 3, 1);



